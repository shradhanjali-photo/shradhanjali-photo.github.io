/*global qq */
qq.version = "5.7.1";
